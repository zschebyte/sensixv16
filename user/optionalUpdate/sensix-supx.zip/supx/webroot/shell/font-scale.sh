for ns in system secure global; do
  val=$(settings get "$ns" font_scale 2>/dev/null)
  if [ "$val" != "null" ]; then
    echo "$val" > /sdcard/font-scale.txt
    break
  fi
done

# WARNING 
# Jangan mengubah properti apapun karena bisa menyebabkan UI sensix rusak !!
# Do not change any properties as it may cause the sensix UI to break!!
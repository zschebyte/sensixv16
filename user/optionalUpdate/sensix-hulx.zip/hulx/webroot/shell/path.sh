# /sdcard/Android/data/com.dts.freefireth/files/ImageCache/
# /sdcard/Android/data/com.dts.freefiremax/files/ImageCache/